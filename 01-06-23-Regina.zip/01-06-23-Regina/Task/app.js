const express = require("express");
const app = express();
const mongoose = require("mongoose");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB database
//mongoose.connect("mongodb://localhost:27017/mydatabase", { useNewUrlParser: true, useUnifiedTopology: true })
    //.then(() => console.log("Successful connection to the database"))
    //.catch(error => console.error("Error connecting to the database:", error));

// Define the model schema
//const transformedDataSchema = new mongoose.Schema({
    //transformedJson: Object
//});

// Define the model
//const TransformedData = mongoose.model("TransformedData", transformedDataSchema);

app.put("/alpha", async (req, res) => {
    try {

        // Get the JSON sent in the PUT request
        const json = req.body;
        
        // Sort the keys of the JSON alphabetically
        const transformedJson = sortKeysAlphabetically(json);

        // Save the transformed JSON in the database
        //const transformedData = await TransformedData.create({ transformedJson });

        // Return the transformed JSON as the response
        res.json(transformedJson);
        //res.json(transformedData.transformedJson);
    } catch (error) {
        console.error("Error in the PUT request:", error);
        res.status(500).json({ message: "Error in the PUT request" });
    }
});

app.post("/flatten", async (req, res) => {
    try {
        const json = req.body;
        Object.keys(json).forEach(key=>{
            if(Array.isArray(json[key]) == true){
                const test = json[key].join(",");
                json[key] = test;
            }
        });
        res.json(json);
    } catch (error) {
        console.error("Error in the POST request:", error);
        res.status(500).json({ message: "Error in the POST request" });
    }
});

app.post("/quote", async (req, res) => {
    
});

app.get("/quotes", async (req, res) => {
    
});

function sortKeysAlphabetically(json) {
    // Sort the keys of the JSON alphabetically
    const sortedJson = {};
    const keys = Object.keys(json);
    keys.sort().forEach(key => {
        sortedJson[key] = json[key];
    });
    return sortedJson;
}

app.listen(3000, (err) => {
    if (err) {
        console.error(err);
    } else {
        console.log("Listening on port 3000");
    }
});
